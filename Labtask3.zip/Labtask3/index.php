<!DOCTYPE html>
<head>
    <title>Registration</title>
</head>

<body >
    <h1 align='center'>Welcome to the site</h1>
    <h3 align='center'>Click on registration: <a href="./view/registrationForm.php" align='center'>Registration</a></h3>
    
</body>
</html>