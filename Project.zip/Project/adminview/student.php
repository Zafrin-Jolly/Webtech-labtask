<<!DOCTYPE html>
<html>
<head>
<title> student information Page  </title>
</head> 
 <body>
    <h1 align="center"> student information Page </h1>
   
  
    <h1> <h1 align="center"> Welcome student  </h1> 
    <br/>

</body> 

</html>
//border = "3" align="center"