<<!DOCTYPE html>
<html>
<head>
<title> Department information Page  </title>
</head> 
 <body>
    <h1 align="center"> Department information Page </h1>
   
  
    <h1> <h1 align="center"> Department   </h1> 
    <br/>

</body> 

</html>