<<!DOCTYPE html>
<html>
<head>
<title> Course information Page  </title>
</head> 
 <body>
    <h1 align="center"> Course information Page </h1>
   
  
    <h1> <h1 align="center"> Course   </h1> 
    <br/>

</body> 

</html>