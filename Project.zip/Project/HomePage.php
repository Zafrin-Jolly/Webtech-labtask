<!DOCTYPE HTML>
<html>
<head>
<title>Aiub portal</title>
</head>

<h1><b>Americal International University-Bangladesh</b>
<img src="logo.jpg" width="50" height="50" title="Logo of a company" alt="Logo of a company" />
<table align='right'>
<tr > 
<td><b><a href="login.php"> Login </b></td> 
<td><b> <a href="ApplyNow.php"> Apply </b></td>
</tr>
</table></h1>
<h2><b>Where leaders are created</b>
<table align='right'>
<tr > 
<td><b><a href="ContactUs.php"> Contact Us </b></td> 
</tr>
</table>  </h2>



<body>
  
</html>