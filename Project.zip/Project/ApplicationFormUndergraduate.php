<!DOCTYPE HTML>
<html>
<head>
<title>Applocation form</title>
<h1 align='center'>Application Form</h1>
<table align='center'>
<form action="" method="post">
<tr >

<td><input type="text" name="username" placeholder="Enter your full Name" ></td>
<td><input type="text" name="email" placeholder="Enter Your Email" ></td>
</tr>
<tr>
    <td><input type="text" name="mobilenumber" placeholder="Enter mobile number" ></td>
    <td><input type="text" name="otp" placeholder="Enter OTP" ></td>
</tr>
<tr>
    <td><input type="text" name="presentaddress" placeholder="Your present Address" ></td>
    <td><input type="text" name="permanentaddress" placeholder="Your permanent Address" ></td>
</tr>
<tr>
<td><input type="text" name="ssc" placeholder="SSC Result" ></td>
    <td><input type="text" name="hsc" placeholder="HSC Result" ></td>
</tr>
<tr>
    <td><input type="file" name="filetoupload" placeholder="SSC Result" ></td>
</tr>
<tr>
   
    <td><input name="submit" type="submit" value="Register"></td></tr>
</form>
</table>

</head>
</html>