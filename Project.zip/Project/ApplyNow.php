<!DOCTYPE HTML>
<html>  
<head>
<title>Applying</title>
</head>
<h1 align='center'>Choose program type</h1>
<table align='center'>
<tr>
<td><b><a href="Undergraduation.php">Undergraduation</b>
</td></tr>
<tr>
<td><b><a href="Graduation.php">Graduation</b>
</td>
</tr></b>
</table>
</html>