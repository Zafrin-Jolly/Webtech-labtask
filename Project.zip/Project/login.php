<!DOCTYPE HTML>
<html>  
<head>
<title>login</title>
</head>
<h1 align='center'>What type of user are you!</h1>
<table align='center'>
<tr>
<td><b><a href="adminview/login.php">Admin</b>
</tr>
<tr>
<td><b><a href="facultyview/login.php">Faculty</b>
</tr>
<tr>
<td><b><a href="studentview/login.php">Student</b>
</td></tr>
<tr>
</tr></b>
</table>
</html>