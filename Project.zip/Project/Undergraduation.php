<!DOCTYPE HTML>
<html>  
<head>
<title>Applying</title>
</head>
<h1 align='center'>Choose academic course</h1>
<table align='center'>
<tr>
<td><a href="ApplicationFormUndergraduate.php"> Bsc in Computer Science & Engineering</td>
</tr>
<tr>
<td><a href="ApplicationFormUndergraduate.php"> Bsc in Electrical & Electronic Engineering</td>
</tr>
<tr>
<td><a href="ApplicationFormUndergraduate.php"> Bsc in Computer Engineering</td>
</tr>
<tr>
<td><a href="ApplicationFormUndergraduate.php"> BA in English</td>
</tr>
<tr>
<td><a href="ApplicationFormUndergraduate.php">BA in Law</td>
</tr>
<tr>
<td><a href="ApplicationFormUndergraduate.php">Bachelor of Business Administration</td>

</tr>
</table>
</html>