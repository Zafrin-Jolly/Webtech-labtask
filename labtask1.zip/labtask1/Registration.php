<DOCTYPE HTML>
<html>
<head><b>Welcome to my page</b></head>
<title>Lab-task-1</title>
<body>
<h1>REGISTRATION</h1>

<form>
<table>
<tr>
<td>Name:</td>
<td><input type="text"id="f"name="fname"></td>
</tr>
<tr>
<td>Email:</td>
<td><input type="text"id="e"name="ename"></td>
</tr>
<tr>
<td>User name:</td>
<td><input type="text"id="u"name="uname"></td>
</tr>
<tr>
<td>password:</td>
<td><input type="text"id="p"name="pname"></td>
</tr>
<tr>
<td>confirm password:</td>
<td><input type="text"id="p"name="pname"></td>
</tr>

<tr>
    <td>Gender <br>
    <input type="radio" id="male" name="gender" value="male">
    Male
    <input type="radio" id="female" name="gender" value="female">
    Female
    <input type="radio" id="other" name="gender" value="other">
    Other</td>
    </tr>      
    <tr>
    <td>Date of Birth <br>  
    <input type="date" id="birthday" name="birthday"></td>
    </tr> 
    <tr>
    <td><input type="submit" value="SUBMIT">
    <input type="reset" value="RESET"></td>
    </tr>
    </table>
    </form>

</body>
</html>
